import { takeAction } from './js/app';
import { inputCheck } from './js/inputCheck';
import {dateCheck} from './js/dateCheck';
import './styles/style.scss';
import 'regenerator-runtime/runtime';
import imgHot from './media/hot.png';
import imgCold from './media/cold.png';

window.addEventListener('DOMContentLoaded', init);

function init(){
document.getElementById("generate").addEventListener('click', takeAction);
};
















export {takeAction}
export {inputCheck}
export {dateCheck}
export {imgHot}
export {imgCold}
