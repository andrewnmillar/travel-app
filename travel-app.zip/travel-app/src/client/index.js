import { takeAction } from './js/app';
import './styles/style.scss';















export {takeAction}