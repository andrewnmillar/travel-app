import {dateCheck} from './dateCheck.js'

describe('check if date is in the past', () => {
    test('should log a message if input is positive', () => {
        const input = "2";
        const output = console.log("Valid Date")
        expect(dateCheck(input)).toEqual(output);
    })
})