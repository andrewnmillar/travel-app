//Check Input Function 

function inputCheck(input) {
    console.log("running inputCheck", input);
    if (input.length === 0) {
      alert("You're Going Nowhere!")
    }
    else {
      console.log("Valid Entry")
    }
  }
  
  export { inputCheck }