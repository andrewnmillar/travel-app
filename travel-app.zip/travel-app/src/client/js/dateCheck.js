function dateCheck(input) {
    console.log("running dateCheck", input);
    if (input<-1) {
      alert("You're gonna need a time machine!")
    }
    else {
      console.log("Valid Date")
    }
  }
  
  export { dateCheck }