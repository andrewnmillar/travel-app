// Global Variables 
const baseURL = `http://api.geonames.org/postalCodeSearchJSON?placename=`
const userName = "&username=andrewnmillar";

//Get Function
const getCoordinates = async (baseURL, place, name)=>{
    const res = await fetch(baseURL+place+name)
    try {
    const data = await res.json();
      console.log(data)
      return data;
    }  catch(error) {
      console.log("error", error);
    }
}

//Post Function
const postData = async ( url = "", data = {} )=>{
    console.log(data)
    const response = await fetch(url, {
    method: 'POST', // *GET, POST, PUT, DELETE, etc.
    credentials: 'same-origin', // include, *same-origin, omit
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(data), // body data type must match "Content-Type" header        
    });

      try {
        const newData = await response.json();
        console.log(newData);
        return newData
      }catch(error) {
      console.log("error", error);
      // appropriately handle the error
      }
}
 
//Update UI Function
 const updateUI = async () => {
     const request = await fetch("http://penguin.termina.linux.test:3000/all")
     try{
     const allData = await request.json()
     console.log(allData);
     document.getElementById("date").innerHTML = allData[allData.length - 1].date;
     document.getElementById("temp").innerHTML = allData[allData.length - 1].temp + " degrees kelvin";    
     document.getElementById("content").innerHTML = allData[allData.length - 1].response;    
     
    }catch(error){
        console.log("error", error)
    }
}

     
//Main Event Function 
//document.getElementById("generate").addEventListener("click", takeAction);

function takeAction(event){
    event.preventDefault()
    let userReponse = document.getElementById("feelings").value;
    let userDestination = document.getElementById("zip").value;
    let d = new Date();
    let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();
    getCoordinates(baseURL, userDestination, userName)
    .then(function(data){
        console.log(data);
        postData("http://penguin.termina.linux.test:3000/postData", {data})
        updateUI();
    })
}    

export {takeAction}