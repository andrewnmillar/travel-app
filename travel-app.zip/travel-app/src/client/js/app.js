//Imported Images
import imgHot from '../media/hot.png';
import imgCold from '../media/cold.png';

// Global Variables 
const baseURLGeo = `http://api.geonames.org/searchJSON?name=`
const userName = "&maxRows=1&username=andrewnmillar";
const baseURLWeather = "http://api.weatherbit.io/v2.0/current"
const content = document.getElementById("content")

//Get Function
const getCoordinates = async (url, place, name)=>{
    const res = await fetch(url+place+name)
    try {
    const data = await res.json();
      console.log(data)
      return data;
    }  catch(error) {
      console.log("error", error);
    }
}

//Post Function
const postData = async ( url = "", data = {} )=>{
    console.log(data)
    const response = await fetch(url, {
    method: 'POST', 
    credentials: 'same-origin', 
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(data), 
    });

      try {
        const newData = await response.json();
        console.log(newData);
        return newData
      } catch(error) {
        console.log("error", error);
      }
}
 
//Update UI Function
 const updateUI = async () => {
     const request = await fetch("http://localhost:3000/all")
     try{
     const allData = await request.json()
     console.log(allData);
     //populate display fields
     const description = document.getElementById("description");
     description.innerHTML = allData.weather.description;
     description.style.backgroundColor = "white";
     const temp = document.getElementById("temp");
     temp.innerHTML = allData.weather.temp + " degrees celcius"; 
     temp.style.backgroundColor = "white";   
     const title = document.getElementById("title");
     title.style.backgroundColor = "white"; 
     const entry = document.getElementById("entry");
     //Change Background Photo
     const imgUrl = await allData.photo.url;
     entry.style.backgroundImage = 'url('+imgUrl+')';
     
     //Display Icons 
     content.style.backgroundColor = "white"; 
     const icon = new Image();
     icon.width = "40";
     icon.height = "40";
     if (allData.weather.temp>14){
      icon.src = imgHot;
      content.appendChild(icon);
     }
     else {
      icon.src = imgCold;
      content.appendChild(icon);
     }
    } catch(error) {
        console.log("error")
    }
}
//Main Function 

async function takeAction(event){
    event.preventDefault()
    //Remove Icon
    if (content.hasChildNodes()) {
      content.removeChild(content.childNodes[0]);
    };
    //Check Inputs
    let userDestination = document.getElementById("dest").value;
    Client.inputCheck(userDestination);
    const travelDate = document.getElementById("date").value;
    let countDownDate = new Date(travelDate).getTime();
    let now = new Date().getTime();
    let distanceDays = (countDownDate - now)/ (1000 * 60 * 60 * 24);
    Client.dateCheck(distanceDays);
    //Fetch Coordinates
    await getCoordinates(baseURLGeo, userDestination, userName)
    .then(async function(data){
        console.log(data);
    //Post Coordinates + User Data
    let response = await postData("http://localhost:3000/postData", {destination: userDestination, date: travelDate, interval: distanceDays, lat: data.geonames[0].lat, lng: data.geonames[0].lng, country: data.geonames[0].countryCode});
      try {
        let res = await response.json();
        console.log(res);
      } catch {
        console.log("error");
      }
      updateUI();
      })
}    

export {takeAction}

