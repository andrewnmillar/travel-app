
import {inputCheck} from './inputCheck.js'

describe('check if input is blank', () => {
    test('should return alert if input length is zero', () => {
        const input = "Paris";
        const output = console.log("Valid Entry")
        expect(inputCheck(input)).toEqual(output);
    })
})