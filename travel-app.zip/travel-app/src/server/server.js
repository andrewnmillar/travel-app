const dotenv = require('dotenv');
dotenv.config();
const fetch = require('node-fetch');
//empty JS object to act as endpoint for all routes
endPoint = {};

// Express to run server and routes
const express = require('express');

// Start up instance of app
const app = express();

//Middleware configuration
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());

// Initialize main project folder
app.use(express.static('dist'));

// Setup Server
const port = 3000;
const server = app.listen(port, listening);
function listening(){
    console.log(`running on localhost: ${port}`);
};

//JS object for GET request
let apiData = {};

app.get('/', function (req, res) {
  res.sendFile('dist/index.html')
})

//Get Route
app.get("/all", function (req, res) {
  res.send(apiData);
  console.log(apiData);
})

//Post Route
app.post("/postData", async (req,res) => {
  let userData = await req.body;
  let lat = userData.lat;
  let lng = userData.lng; 
  let interval = (userData.interval*1).toFixed(0);
  let dest = userData.destination;
  let country = userData.country;
  console.log(userData);
  //Fetch background image
  let pixaResponse = await fetch(`https://pixabay.com/api/?key=${process.env.PIXABAY_KEY}&q=${encodeURIComponent(dest)}+${encodeURIComponent(country)}&image_type=photo`) 
  try{let pixaRes = await pixaResponse.json();
    console.log(pixaRes);
  apiData.photo = {url: pixaRes.hits[0].webformatURL}
  } catch {
    console.log("error");
  }
//Check when trip is and fetch appropriate weather data
  if (interval<7) {
    let response = await fetch(`http://api.weatherbit.io/v2.0/current?lat=${lat}&lon=${lng}&key=${process.env.WEATHER_BIT_KEY}`)
    try {
      let res = await response.json();
      apiData.weather = {temp: res.data[0].temp, description: res.data[0].weather.description};
      console.log(apiData);
        } catch {
        console.log("error");
  }
  }
  else if (interval>7 && interval<16) {
    let response = await fetch(`http://api.weatherbit.io/v2.0/forecast/daily?lat=${lat}&lon=${lng}&key=${process.env.WEATHER_BIT_KEY}`)
    try { 
      let res = await response.json();
      apiData.weather = {temp: res.data[interval].temp, description: res.data[interval].weather.description};
      console.log(res);
      console.log(apiData);
        } catch {
        console.log("error");
  }
  }
  else {
    let response = await fetch(`http://api.weatherbit.io/v2.0/forecast/daily?lat=${lat}&lon=${lng}&key=${process.env.WEATHER_BIT_KEY}`)
    try { 
      let res = await response.json();
      apiData.weather = {temp: res.data[15].temp, description: res.data[15].weather.description};
      console.log(res);
      console.log(apiData);
        } catch {
        console.log("error");
  }
  };
    res.send(apiData);
  console.log(apiData);
});


