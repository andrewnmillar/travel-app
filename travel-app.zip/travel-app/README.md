# Travel App Project

## Overview
This project demonstrates the use of asynchronous javascript and server side code to fetch multiple Web APIs and user data to dynamically update the UI. 
The concept is a one page app that displays a weather forcast for the user based on a planned trip. If the trip date is within 7 days, the app will display current weather. If the trip is between 7 and 16 days, the app will display a weather forecast for the arrival date. If the trip date is later than 16 days from present, the app displays the latest possible weather data. If the returned temp is above 14 degrees C a "warm" thermometer icon is displayed. If the temp is below 14 C a "cold" thermometer icon is displayed. Meanwhile, the background image updates dynamically based on the destination data. 

## Directions
To run the app please create an ENV file named '.env' in the root directory. Create variables for keys for the weatherbit and pixabay APIs. I've used the variable names WEATHER_BIT_KEY and PIXABAY_KEY in the code. 
This app also uses the following dependencies:
babel, babel loader, css loader, file loader, html loader, html webpack plugin, node sass, sass loader, style loader, webpack, webpack cli, mini-css-extract-plugin, optimize-css-assets-webpack-plugin, terser-webpack-plugin and webpack dev server.
To build the app run 'npm run build-dev', 'npm run build-prod' and 'npm start' respectively in the command line.   
*note* As of this writing pixabay has been experiencing some outages. Hopefully this won't present an issue with testing. 
 

## Extras
For this project, I've chosen to implement dynamically changing icons as an optional addition.
